HAMZA & AMMARA — UPDATED INVITATION

Upload index.html, personalize.html and the assets folder together.

NEW FEATURES
- Urdu / English button: switches website text. The video keeps its original text.
- Music button: starts/stops the supplied wedding MP3. Music starts on the invitation opening tap; the music button then switches it off/on.
- Soft scroll animations, with reduced-motion support.
- Personal invitation: open personalize.html after hosting. Paste the website link, enter the guest name, optionally enter an Urdu name, then create and copy the link.

Example: https://your-site.com/?guest=Ahmed%20%26%20Family
Without a guest name, the site shows the usual invitation.
The personal greeting appears directly below the opening video.

Runethia video, programme times, fixed venue location and updated family contacts are included.
No RSVP or dress-code section is included.

SIGNATURE ADDITIONS
Expandable wedding dua, personalized envelope before video, and one-time closing petals. Guest name is set using personalize.html. Generic links keep the original video opening. Countdown remains unchanged.
Dua source: https://sunnah.com/abudawud:2130

LOADING & SCREEN FITTING
Opening poster, tap-only playback, bilingual loading status and retry button for slow/failed video loads. Video stays uncropped. Responsive controls, countdown, contact rows and landscape envelope layout. Google Maps requires internet. Device/browser visual testing is still needed.

CUSTOM MUSIC
Your supplied MP3 is included unchanged. It starts on the opening tap, loops, and can be switched off/on. Switching language or retrying video does not restart music after you turn it off.
