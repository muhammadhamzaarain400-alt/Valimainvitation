(() => {
 const video=document.querySelector('#openingVideo video'),panel=document.getElementById('videoStatus'),label=document.getElementById('videoStatusText'),retry=document.getElementById('retryVideo');
 let requested=false,finished=false,pending=false,timer,state='idle',attempt=0;
 function render(){const ur=document.documentElement.lang==='ur';const messages={loading:ur?'ویڈیو لوڈ ہو رہی ہے…':'Loading your invitation…',slow:ur?'انٹرنیٹ سست ہے، براہِ کرم انتظار کریں۔':'Taking a little longer. Please wait.',error:ur?'ویڈیو نہیں چل سکی۔ دوبارہ کوشش کریں۔':'The video could not play. Please try again.'};label.textContent=messages[state]||'';retry.textContent=ur?'دوبارہ کوشش کریں':'Retry';panel.hidden=!['loading','slow','error'].includes(state);retry.hidden=!['slow','error'].includes(state);panel.classList.toggle('has-error',state==='error');video.setAttribute('aria-busy',String(state==='loading'||state==='slow'));}
 function setState(next){state=next;render();clearTimeout(timer);if(next==='loading')timer=setTimeout(()=>setState('slow'),12000);}
 function failure(){pending=false;setState('error');document.dispatchEvent(new Event('invitationerror'));}
 async function start(event){
  if(finished)return;
  const explicit=event?.type==='invitationopen'||event?.currentTarget===retry;
  if(!explicit && event?.target?.closest?.('.invitation-controls,button,a,input,select,textarea,summary'))return;
  const envelope=document.getElementById('guestEnvelope');if(envelope&&!envelope.hidden&&!explicit)return;
  if(pending || (requested&&!video.paused&&state!=='error'))return;
  const firstOpen=!requested;
  requested=true;pending=true;const token=++attempt;
  if(firstOpen) document.dispatchEvent(new Event("invitationmusicstart"));
  if(state==='error'||state==='slow'){video.load();}
  setState('loading');
  try{await video.play();if(token!==attempt)return;pending=false;setState('playing');}catch(error){if(token===attempt)failure();}
 }
 retry.addEventListener('click',event=>{event.stopPropagation();pending=false;start(event)});
 document.addEventListener('invitationopen',start);
 document.addEventListener('click',start);
 video.addEventListener('playing',()=>{pending=false;setState('playing')});
 video.addEventListener('waiting',()=>{if(requested&&!finished)setState('loading')});
 video.addEventListener('stalled',()=>{if(requested&&!finished&&video.readyState<3)setState('loading')});
 video.addEventListener('error',()=>{if(requested)failure()});
 video.addEventListener('ended',()=>{finished=true;setState('ended')});
 video.addEventListener('pause',()=>{if(!finished&&!pending&&state==='playing')setState('idle')});
 new MutationObserver(render).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});render();
})();
